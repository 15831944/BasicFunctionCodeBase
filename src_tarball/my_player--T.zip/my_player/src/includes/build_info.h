#ifndef __BUILD_INFO_H__
#define __BUILD_INFO_H__
 
 
#define g_make_build_date             "Fri Apr 10 16:27:56 CST 2015"
#define g_make_build_user_name        "root"
#define g_make_build_host_name        "sun-desktop"
#define g_make_build_kernel_revision  "Linux 2.6.32-33-generic i686"
#define g_make_svn_version    "5325"
#define g_make_major_version  "1"
#define g_make_minor_version  "0"
#define g_make_build_version  "1.0.5325"
 
#endif //__BUILD_INFO_H__
