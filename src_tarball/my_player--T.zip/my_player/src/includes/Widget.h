#ifndef __WIDGET_H__
#define __WIDGET_H__

/**
 *  widget log模块注册
 **/
int log_ui_init();

#endif

