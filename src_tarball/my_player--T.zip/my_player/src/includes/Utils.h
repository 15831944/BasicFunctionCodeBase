#ifndef __UTILS_H__
#define __UTILS_H__

/**
 *  utils log模块注册
 **/
int log_utils_init();

#endif

