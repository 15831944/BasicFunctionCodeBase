#ifndef __Monitor_H__
#define __Monitor_H__

/**
 *  monitor log模块注册
 **/
int log_monitor_init();

#endif

