#ifndef __PLAYER_H__
#define __PLAYER_H__

/**
 *  player log模块注册
 **/
int log_player_init();


#endif

