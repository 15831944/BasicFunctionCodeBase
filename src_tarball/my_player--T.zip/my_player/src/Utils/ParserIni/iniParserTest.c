#include <stdio.h>

#include "log/LogC.h"
#include "logParseFiles.h"
#include "Utils.h"

extern int log_utils_init();

int main()
{
    
    printf("log_utils_init==============\n");
    return 0;
}

