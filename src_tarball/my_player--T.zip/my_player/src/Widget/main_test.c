#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include "log/log_c.h"
#include "player.h"


int main(int argc, char* argv[])
{
    
    
    
    
    return 0;
}





