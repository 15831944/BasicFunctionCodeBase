/**
线程：
    1、界面
    2、音视频解码
    3、消息处理

**/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>



int main(int argc, char* argv[])
{
    
    
    
    return 0;
}

























